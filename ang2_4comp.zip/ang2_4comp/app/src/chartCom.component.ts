import { Component } from '@angular/core';
 
// @Component({
//     selector: 'simple-chart-example',
//     template: `
//         <chart [options]="options"></chart>
//     `
// })
// export class ChartComponent {
//     constructor() {
//         this.options = {
//             title : { text : 'simple chart' },
//             series: [{
//                 data: [29.9, 71.5, 106.4, 129.2],
//             }]
//         };
//     }
//     options: Object;
// }
@Component({
    selector: 'chart-com',
    styles: [`
      chart {
        display: block;
      }
    `],
    template: `<chart [options]="options"></chart>`
})
export class ChartComponent {
    constructor() { 
        this.options = {
            chart: {
                type: 'areaspline',
                margin: 75,
                options3d: {
                    enabled: true,
                    alpha: 15,
                    beta: 15,
                    depth: 50
                }
            },
            plotOptions: {
                column: {
                    depth: 25
                }
            },
            series: [{
                data: [29.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]
            }]
        };
    }
    options: Object;