export class Person {
name: string;
  height: number;
   weight: number;
 
}