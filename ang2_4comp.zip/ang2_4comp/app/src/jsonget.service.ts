import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';

@Injectable()
export class AppServices{
   constructor(private http:Http) { }
  // Uses http.get() to load a single JSON file
getFoods() {
    return this.http.get('https://api.github.com/users/hadley/orgs').map((res:Response) => res.json());
  }
}
