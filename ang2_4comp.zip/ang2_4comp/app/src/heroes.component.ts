import { Component } from '@angular/core';

@Component({
  selector: 'heroes',
  template: `<h3>My Dashboard</h3>
  <input (keyup)="onKey($event)" name="lastName" [(ngModel)]="lastName">
  <p>{{values}}</p>
  <button (click)=onKey1(lastName)>click</button>
  <p>{{values1}}</p>

  <input [value]="username1" (input)="username = $event.target.value" >

<p>Hello {{username}}!</p> `
})
export class HeroComponent { 

 values = '';
 values1 = '';

  onKey(event: any) { // without type info
    this.values = event.target.value ;
    localStorage.setItem('heroes',JSON.stringify(this.values));
  }
  onKey1(lastName: any) { // without type info
  	console.log(lastName);
    this.values1 = lastName;
    localStorage.setItem('heroes1',JSON.stringify(this.values1));
  }

  }