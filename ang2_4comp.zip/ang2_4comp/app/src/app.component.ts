import { Component } from "@angular/core";
import { HomeComponent }  from './home.component';
import { HeroComponent }  from './heroes.component';
import { PeopleListComponent }  from './peopleList.component';
import { FormValidationComponent }  from './home-form.component';
import { JsonComponent }  from './jsonCom.component';
import { ChartComponent }  from './chartCom.component';



@Component({
   selector: 'my-app',
  template: `<h2>My First Angular 2 App {{name}}</h2>
  <a routerLink="/heroes">Heroes</a>
  <a routerLink="/home">Home</a>
  <a routerLink="/peopleList">peopleList</a>
  <a routerLink="/home-form">Forms</a>
   <a routerLink="/jsonCom">fetching json data</a>
   <a routerLink="/chartCom">chart</a>
   <router-outlet></router-outlet>`

})


export class AppComponent {
	 name = 'karthi';

}