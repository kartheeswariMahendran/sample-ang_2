import { Component } from '@angular/core';

import { AppServices } from './jsonget.service';

@Component({
  selector: 'people-list',
  template: `
  <!-- this is the new syntax for ng-repeat -->
  <ul>
    <li *ngFor="let i of data1">
        {{i.login}}
    </li>
  </ul>
  `
})
export class JsonComponent {
   data1:any;
  constructor(private _appService : AppServices){
    this._appService.getFoods().subscribe(data => { this.data1 = data} );
  }
}