import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { ChartModule } from 'angular2-highcharts';
import { HomeComponent }  from './home.component';
import { HeroComponent }  from './heroes.component';
import { PeopleListComponent }  from './peopleList.component';
import { FormValidationComponent }  from './home-form.component';
import { JsonComponent }  from './jsonCom.component';
import { AppComponent }  from './app.component';
import { ChartComponent }  from './chartCom.component';
import { Person } from './people';
import { PeopleService } from './people.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppServices } from './jsonget.service';
import 'rxjs/add/operator/map';


@NgModule({
  imports 		: [ BrowserModule ,
                  RouterModule.forRoot([
                  {path: '',component: HomeComponent },
                  {path: 'home',component: HomeComponent},
             	    {path: 'heroes',component: HeroComponent}, 
             	    {path: 'peopleList',component: PeopleListComponent},
                   {path: 'home-form',component: FormValidationComponent},
                   {path: 'jsonCom',component: JsonComponent},
                   {path: 'chartCom',component: ChartComponent}
                  ]),
                  FormsModule,
                  ReactiveFormsModule,
                  HttpModule,
                  ChartModule.forRoot(require('highcharts'))
                  ],
  declarations 	: [ AppComponent,HomeComponent,HeroComponent,PeopleListComponent,FormValidationComponent,JsonComponent,ChartComponent ],
  bootstrap 	: [ AppComponent ],
  providers: [ PeopleService,AppServices] 


})

export class AppModule { 

}
